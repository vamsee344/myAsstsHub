My Assets Hub Premium Icon Design System Package
Contains category specifications for 300+ planned icons.