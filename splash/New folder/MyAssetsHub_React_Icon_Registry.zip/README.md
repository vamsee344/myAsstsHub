My Assets Hub React Icon Registry using Lucide React.
Install: npm install lucide-react